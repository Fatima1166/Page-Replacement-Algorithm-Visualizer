# graph_visualizer.py

import matplotlib.pyplot as plt
import networkx as nx

def visualize_resource_allocation_graph(processes, resources, allocation, request):
    try:
        graph = nx.DiGraph()

        # Add process and resource nodes
        for process in processes:
            graph.add_node(process, type="process")
        for resource in resources:
            graph.add_node(resource, type="resource")

        # Add allocation edges (resource → process)
        for i, process in enumerate(processes):
            for j, resource in enumerate(resources):
                if j < len(allocation[i]) and allocation[i][j] > 0:
                    graph.add_edge(resource, process)

        # Add request edges (process → resource)
        for i, process in enumerate(processes):
            for j, resource in enumerate(resources):
                if j < len(request[i]) and request[i][j] > 0:
                    graph.add_edge(process, resource)

        # Position layout
        process_nodes = [node for node, data in graph.nodes(data=True) if data["type"] == "process"]
        resource_nodes = [node for node, data in graph.nodes(data=True) if data["type"] == "resource"]
        pos = {}
        pos.update((node, (0, i)) for i, node in enumerate(process_nodes))
        pos.update((node, (2, i)) for i, node in enumerate(resource_nodes))

        # Draw the graph
        plt.figure(figsize=(10, 6))
        nx.draw_networkx_nodes(graph, pos, nodelist=process_nodes, node_color="skyblue", node_size=2000, label="Processes")
        nx.draw_networkx_nodes(graph, pos, nodelist=resource_nodes, node_color="lightgreen", node_size=2000, label="Resources")
        nx.draw_networkx_edges(graph, pos, width=1.0, alpha=0.8)
        nx.draw_networkx_labels(graph, pos, font_size=12, font_family="sans-serif")
        plt.title("Resource Allocation Graph")
        plt.legend(loc="upper right")
        plt.axis("off")
        plt.show()

    except Exception as e:
        print(f"❌ Error drawing graph: {e}")
