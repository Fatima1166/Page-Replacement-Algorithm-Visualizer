class DeadlockDetection:
    def __init__(self, processes, total_resources, allocation, request):
        self.processes = processes
        self.total_resources = total_resources
        self.allocation = allocation
        self.request = request

        # ✅ Validate input dimensions before proceeding
        if not all(len(row) == len(total_resources) for row in allocation + request):
            raise ValueError("❌ Mismatch: Each allocation and request row must match the number of resource types.")

        # Calculate available resources
        self.available = [
            self.total_resources[i] - sum(self.allocation[j][i] for j in range(len(processes)))
            for i in range(len(total_resources))
        ]

    def is_safe(self):
        work = self.available[:]
        finish = [False] * len(self.processes)
        safe_sequence = []

        while True:
            found = False
            for i in range(len(self.processes)):
                if not finish[i] and all(self.request[i][j] <= work[j] for j in range(len(work))):
                    for j in range(len(work)):
                        work[j] += self.allocation[i][j]
                    finish[i] = True
                    safe_sequence.append(self.processes[i])
                    found = True
            if not found:
                break

        if all(finish):
            return True, safe_sequence
        else:
            return False, [self.processes[i] for i, done in enumerate(finish) if not done]

    def detect_deadlock(self):
        is_safe_state, info = self.is_safe()
        if is_safe_state:
            return f"✅ No deadlock detected. Safe sequence: {', '.join(info)}"
        else:
            return f"⚠️ Deadlock detected! Processes involved: {', '.join(info)}"

