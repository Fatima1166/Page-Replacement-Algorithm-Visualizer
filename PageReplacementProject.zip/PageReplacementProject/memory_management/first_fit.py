class FirstFit:
    def __init__(self, memory_blocks):
        self.original_blocks = memory_blocks[:]
        self.memory_blocks = memory_blocks[:]
        self.allocation = {}

    def allocate(self, process_name, process_size):
        for i, block_size in enumerate(self.memory_blocks):
            if block_size >= process_size:
                self.allocation[process_name] = (i, process_size)
                self.memory_blocks[i] -= process_size
                return True
        return False

    def get_allocation(self):
        return self.allocation

    def get_memory_blocks(self):
        return self.memory_blocks

    def get_original_blocks(self):
        return self.original_blocks
