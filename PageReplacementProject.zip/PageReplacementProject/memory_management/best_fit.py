class BestFit:
    def __init__(self, memory_blocks):
        self.original_blocks = memory_blocks[:]
        self.memory_blocks = memory_blocks[:]
        self.allocation = {}

    def allocate(self, process_name, process_size):
        best_block_index = -1
        min_waste = float('inf')

        for i, block_size in enumerate(self.memory_blocks):
            if block_size >= process_size:
                waste = block_size - process_size
                if waste < min_waste:
                    min_waste = waste
                    best_block_index = i

        if best_block_index != -1:
            self.allocation[process_name] = (best_block_index, process_size)
            self.memory_blocks[best_block_index] -= process_size
            return True
        return False

    def get_allocation(self):
        return self.allocation

    def get_memory_blocks(self):
        return self.memory_blocks

    def get_original_blocks(self):
        return self.original_blocks



