from tabulate import tabulate
import matplotlib.pyplot as plt

def visualize_memory_allocation(algorithm_name, memory_blocks, allocation, original_blocks):
    table_data = []

    for i, (orig, remaining) in enumerate(zip(original_blocks, memory_blocks)):
        block_no = f"Block {i+1}"
        allocated_processes = []
        allocated_total = 0

        for process, (block_index, size) in allocation.items():
            if block_index == i:
                allocated_processes.append(process)
                allocated_total += size

        table_data.append([
            block_no,
            orig,
            ", ".join(allocated_processes) if allocated_processes else "-",
            allocated_total if allocated_total else 0,
            remaining
        ])

    headers = ["Block No", "Original Size", "Allocated To", "Allocated Size", "Remaining Size"]
    print(f"\n{algorithm_name} Memory Allocation Table:\n")
    print(tabulate(table_data, headers=headers, tablefmt="grid"))

    # Plotting
    x_labels = [f"Block {i+1}" for i in range(len(memory_blocks))]
    plt.figure(figsize=(8, 4))
    plt.bar(x_labels, original_blocks, color='lightgray', label='Original Size')
    plt.bar(x_labels, memory_blocks, color='skyblue', label='Remaining Size')
    plt.xlabel("Memory Blocks")
    plt.ylabel("Size")
    plt.title(f"{algorithm_name} - Memory Allocation")
    plt.legend()
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()
