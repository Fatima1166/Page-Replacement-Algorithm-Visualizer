class RoundRobin:
    def __init__(self, processes, time_quantum):
        self.processes = processes
        self.time_quantum = time_quantum
        self.completion_times = {}
        self.waiting_times = {}
        self.turnaround_times = {}

    def run(self):
        time = 0
        queue = []
        remaining_bt = {p['name']: p['burst_time'] for p in self.processes}
        arrival_dict = {p['name']: p['arrival_time'] for p in self.processes}
        visited = {p['name']: False for p in self.processes}

        while len(self.completion_times) < len(self.processes):
            # Add newly arrived processes before execution
            for p in self.processes:
                if p['arrival_time'] <= time and not visited[p['name']]:
                    queue.append(p['name'])
                    visited[p['name']] = True

            if not queue:
                time += 1
                continue

            current = queue.pop(0)
            exec_time = min(self.time_quantum, remaining_bt[current])
            time += exec_time
            remaining_bt[current] -= exec_time

            # 🔁 FIXED: Check again for newly arrived processes after execution
            for p in self.processes:
                if p['arrival_time'] <= time and not visited[p['name']]:
                    queue.append(p['name'])
                    visited[p['name']] = True

            # If process not finished, re-queue it
            if remaining_bt[current] > 0:
                queue.append(current)
            else:
                self.completion_times[current] = time
                burst = next(p['burst_time'] for p in self.processes if p['name'] == current)
                arrival = arrival_dict[current]
                self.turnaround_times[current] = time - arrival
                self.waiting_times[current] = self.turnaround_times[current] - burst

    def get_results(self):
        return self.completion_times, self.waiting_times, self.turnaround_times





