class SJF:
    def __init__(self, processes):
        self.processes = processes
        self.completion_times = {}
        self.waiting_times = {}
        self.turnaround_times = {}

    def run(self):
        processes = self.processes[:]
        time = 0
        completed = []
        while len(completed) < len(processes):
            available = [p for p in processes if p['arrival_time'] <= time and p['name'] not in completed]
            if not available:
                time += 1
                continue
            next_process = min(available, key=lambda x: x['burst_time'])
            start = time
            time += next_process['burst_time']
            name = next_process['name']
            self.completion_times[name] = time
            self.turnaround_times[name] = time - next_process['arrival_time']
            self.waiting_times[name] = self.turnaround_times[name] - next_process['burst_time']
            completed.append(name)

    def get_results(self):
        return self.completion_times, self.waiting_times, self.turnaround_times
