class FCFS:
    def __init__(self, processes):
        self.processes = sorted(processes, key=lambda x: x['arrival_time'])
        self.completion_times = {}
        self.waiting_times = {}
        self.turnaround_times = {}

    def run(self):
        current_time = 0
        for p in self.processes:
            arrival = p['arrival_time']
            if current_time < arrival:
                current_time = arrival
            start_time = current_time
            complete = start_time + p['burst_time']
            self.completion_times[p['name']] = complete
            self.turnaround_times[p['name']] = complete - arrival
            self.waiting_times[p['name']] = start_time - arrival
            current_time = complete

    def get_results(self):
        return self.completion_times, self.waiting_times, self.turnaround_times
