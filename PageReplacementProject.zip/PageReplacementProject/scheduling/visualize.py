import matplotlib.pyplot as plt
from tabulate import tabulate

def visualize_scheduling(algorithm_name, completion_times, waiting_times, turnaround_times):
    table_data = []
    for process in completion_times:
        table_data.append([
            process,
            completion_times[process],
            waiting_times[process],
            turnaround_times[process]
        ])

    headers = ["Process", "Completion Time", "Waiting Time", "Turnaround Time"]
    print(f"\n{algorithm_name} Scheduling Results:\n")
    print(tabulate(table_data, headers=headers, tablefmt="grid"))

    total_waiting = sum(waiting_times.values())
    total_turnaround = sum(turnaround_times.values())
    n = len(waiting_times)

    print(f"\nTotal Waiting Time: {total_waiting}")
    print(f"Total Turnaround Time: {total_turnaround}")
    print(f"Average Waiting Time: {total_waiting / n:.2f}")
    print(f"Average Turnaround Time: {total_turnaround / n:.2f}")

    # Gantt chart
    plt.figure(figsize=(10, 4))
    start_times = {}
    for p in completion_times:
        start_times[p] = completion_times[p] - turnaround_times[p]

    for i, process in enumerate(completion_times):
        plt.barh(process, turnaround_times[process], left=start_times[process])

    plt.xlabel("Time")
    plt.ylabel("Processes")
    plt.title(f"{algorithm_name} Gantt Chart")
    plt.grid(True)
    plt.show()
