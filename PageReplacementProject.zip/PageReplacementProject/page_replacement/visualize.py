import matplotlib.pyplot as plt
from tabulate import tabulate
import matplotlib.patches as mpatches

def visualize_page_replacement(algorithm_name, page_faults, page_hits, frame_states, pages):
    """
    Visualizes the page replacement process using a table, a line plot of unique pages,
    and a Gantt chart showing frame usage over time.
    """

    # Create a table of frame states
    table_data = []
    for i, state in enumerate(frame_states):
        flat_state = []
        for item in state:
            if isinstance(item, list):
                flat_state.append(str(item))  # Convert list to string
            else:
                flat_state.append(item)
        table_data.append([pages[i]] + flat_state)

    # Header
    headers = (
        ["Page"] + [f"Frame {i+1}" for i in range(len(frame_states[0]) - 1)] + ["Status"]
        if frame_states else ["Page"]
    )

    table = tabulate(table_data, headers=headers, tablefmt="grid")

    # Print simulation table and stats
    print(f"\n{algorithm_name} Page Replacement Simulation:\n")
    print(table)
    print(f"\nPage Faults: {page_faults}")
    print(f"Page Hits: {page_hits}")
    total = page_faults + page_hits
    hit_ratio = (page_hits / total) if total > 0 else 0
    print(f"Hit Ratio: {hit_ratio:.2f}\n")

    # Unique page counts for plotting
    unique_counts = []
    for state in frame_states:
        cleaned = [tuple(p) if isinstance(p, list) else p for p in state[:-1]]
        unique_counts.append(len(set(cleaned)))

    # Plot 1: Unique Pages Over Time
    plt.figure(figsize=(10, 4))
    plt.plot(range(len(frame_states)), unique_counts, marker='o', color='blue')
    plt.xlabel("Page Access Number")
    plt.ylabel("Unique Pages in Frames")
    plt.title(f"{algorithm_name} - Unique Pages Over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # 🔶 Plot 2: Gantt Chart for Frame Usage
    if frame_states:
        num_frames = len(frame_states[0]) - 1
        fig, ax = plt.subplots(figsize=(12, 6))

        colors = {}  # to assign unique colors to pages
        y_labels = []
        for frame in range(num_frames):
            y_labels.append(f"Frame {frame + 1}")
            start = 0
            prev_page = None
            for t, state in enumerate(frame_states):
                page = state[frame]
                if page != prev_page or t == len(frame_states) - 1:
                    if prev_page is not None:
                        end = t if page != prev_page else t + 1
                        page_label = str(prev_page)
                        if page_label not in colors:
                            colors[page_label] = plt.cm.tab20(len(colors) % 20)
                        ax.barh(y=frame, width=end - start, left=start,
                                color=colors[page_label], edgecolor='black')
                        ax.text((start + end - 1) / 2, frame, page_label,
                                ha='center', va='center', color='white', fontsize=8)
                    start = t
                    prev_page = page

        ax.set_yticks(range(num_frames))
        ax.set_yticklabels(y_labels)
        ax.set_xlabel("Page Access Number")
        ax.set_title(f"{algorithm_name} - Gantt Chart of Frame Usage Over Time")
        ax.grid(True, axis='x', linestyle='--', alpha=0.6)
        plt.tight_layout()
        plt.show()
