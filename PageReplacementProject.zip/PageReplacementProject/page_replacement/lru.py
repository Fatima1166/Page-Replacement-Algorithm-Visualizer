class LRU:
    def __init__(self, capacity):
        self.capacity = capacity
        self.queue = []  # Frames (most recent at end)
        self.page_faults = 0
        self.page_hits = 0
        self.steps = []  # (step, page, frame, status)

    def access_page(self, page, step):
        status = ""
        if page in self.queue:
            self.page_hits += 1
            self.queue.remove(page)
            self.queue.append(page)
            status = "Hit"
        else:
            self.page_faults += 1
            if len(self.queue) == self.capacity:
                self.queue.pop(0)
            self.queue.append(page)
            status = "Fault"
        self.steps.append((step, page, self.queue[:], status))

    def get_results(self):
        return self.page_faults, self.page_hits, self.steps
