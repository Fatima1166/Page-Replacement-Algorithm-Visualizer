class Optimal:
    def __init__(self, capacity):
        self.capacity = capacity
        self.frames = []
        self.page_faults = 0
        self.page_hits = 0
        self.steps = []

    def predict(self, pages, current_index):
        farthest = current_index
        page_to_replace = None
        for page in self.frames:
            try:
                next_use = pages[current_index + 1:].index(page) + current_index + 1
            except ValueError:
                return page  # Not used again
            if next_use > farthest:
                farthest = next_use
                page_to_replace = page
        return page_to_replace or self.frames[0]

    def access_page(self, page, pages, step):
        status = ""
        if page in self.frames:
            self.page_hits += 1
            status = "Hit"
        else:
            self.page_faults += 1
            if len(self.frames) == self.capacity:
                replace = self.predict(pages, step)
                self.frames[self.frames.index(replace)] = page
            else:
                self.frames.append(page)
            status = "Fault"
        self.steps.append((step, page, self.frames[:], status))

    def run_simulation(self, pages):
        for i, page in enumerate(pages):
            self.access_page(page, pages, i)

    def get_results(self):
        return self.page_faults, self.page_hits, self.steps

