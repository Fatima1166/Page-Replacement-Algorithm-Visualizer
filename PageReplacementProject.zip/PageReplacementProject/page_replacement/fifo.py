class FIFO:
    def __init__(self, capacity):
        self.capacity = capacity
        self.queue = []
        self.page_faults = 0
        self.page_hits = 0
        self.steps = []  # List of (step, page, frame, status)

    def access_page(self, page, step):
        status = ""
        if page in self.queue:
            self.page_hits += 1
            status = "Hit"
        else:
            self.page_faults += 1
            status = "Fault"
            if len(self.queue) == self.capacity:
                self.queue.pop(0)
            self.queue.append(page)

        self.steps.append((step, page, self.queue[:], status))

    def get_results(self):
        return self.page_faults, self.page_hits, self.steps

